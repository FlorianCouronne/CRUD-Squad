# Apache SSL configuration – Member 6

File: `C:\xampp\apache\conf\extra\httpd-ssl.conf` (each change marked `[Member 6]` in the file)

| Setting | Before (XAMPP default) | After | Why |
| --- | --- | --- | --- |
| SSLProtocol | `all -SSLv3` | `-all +TLSv1.2 +TLSv1.3` | Refuse old, broken TLS 1.0/1.1 |
| SSLCipherSuite | `HIGH:MEDIUM:!MD5:!RC4:!3DES` | `HIGH:!aNULL:!MD5:!3DES:!RC4` | Strong ciphers only, no anonymous key exchange |
| ServerName | `www.example.com:443` | `localhost:443` | Matches the certificate |

## Certificate

Made with `carlux-cert.cnf` (this folder):

    openssl req -x509 -newkey rsa:2048 -nodes -sha256 -days 825 ^
      -keyout conf\ssl.key\server.key -out conf\ssl.crt\server.crt -config conf\carlux-cert.cnf

- Subject Alternative Name: `localhost`, `127.0.0.1`, `::1`
- RSA 2048-bit, SHA-256, valid 825 days
- Trusted on the demo PC via Windows "Trusted Root Certification Authorities"

The private key `server.key` is NOT in this repository and must never be committed.

## HTTP → HTTPS

`car-lux/.htaccess` redirects every `http://` request to `https://` with a 301.
