<?php
/*
 * Output escaping helper - Member 6 (Security Specialist)
 *
 * XSS (Cross-Site Scripting) happens when text that a user typed is printed
 * into a page as HTML, so a value like <script>...</script> runs as code.
 * e() converts the special HTML characters into harmless entities:
 *     <  ->  &lt;     >  ->  &gt;     "  ->  &quot;     '  ->  &#039;     &  ->  &amp;
 * The browser then shows the text instead of running it.
 *
 * Rule for the whole team: every value that is not fixed HTML written by us
 * (user input, database values, URL parameters) is printed with e().
 *     echo e($value);
 */

if (!function_exists('e')) {
    function e($value): string
    {
        // ENT_QUOTES: also escapes " and ' so values are safe inside attributes.
        // ENT_SUBSTITUTE: replaces invalid UTF-8 instead of returning an empty string.
        return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }
}
