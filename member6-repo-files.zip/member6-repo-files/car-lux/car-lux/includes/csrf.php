<?php
/*
 * Anti-CSRF token helper - Member 6 (Security Specialist)
 *
 * Pattern: "synchronizer token". The server creates a secret random token,
 * stores it in the user's session and puts a copy in every form as a hidden
 * field. When a form is submitted, both copies must match. A malicious
 * website can make the browser send a request, but it cannot read our
 * pages, so it never knows the token and its forged request is rejected.
 *
 * In a form (prints the hidden input):
 *     echo csrf_field();
 *
 * In the script that processes the form, inside the POST branch:
 *     require __DIR__ . '/includes/csrf.php';
 *     csrf_verify();   // stops with 403 Forbidden if the token is missing or wrong
 */

// The token lives in the session, so a session must be running.
// (This only starts one if none exists; session settings are unchanged.)
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

/** Returns this session's token, creating it the first time. */
function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        // 32 random bytes from a cryptographically secure generator = 256 bits,
        // written as 64 hexadecimal characters. Impossible to guess.
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/** The hidden <input> to place inside every POST form. */
function csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="'
        . htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') . '">';
}

/**
 * Checks the submitted token on POST requests.
 * Missing or wrong token -> HTTP 403 Forbidden and the script stops,
 * so nothing after this line (database insert, etc.) ever runs.
 */
function csrf_verify(): void
{
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        return;
    }

    $sent     = $_POST['csrf_token'] ?? '';
    $expected = $_SESSION['csrf_token'] ?? '';

    // hash_equals() compares in constant time, so an attacker cannot
    // learn the token one character at a time by measuring response times.
    if (!is_string($sent) || $expected === '' || !hash_equals($expected, $sent)) {
        http_response_code(403);
        exit('403 Forbidden: invalid or missing security token. Please reload the page and try again.');
    }
}
