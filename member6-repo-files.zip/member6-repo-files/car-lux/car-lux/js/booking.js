// Client-side validation (SR-4). The server must validate again in book_service.php.
// Moved here from booking.php by Member 6 (no logic changed): with a strict
// Content-Security-Policy the browser only runs scripts loaded from files,
// so any <script> injected by an attacker into the page will not run.
document.querySelector('.needs-validation').addEventListener('submit', function (e) {
  if (!this.checkValidity()) { e.preventDefault(); e.stopPropagation(); }
  this.classList.add('was-validated');
});
document.getElementById('date').min = new Date().toISOString().split('T')[0];
