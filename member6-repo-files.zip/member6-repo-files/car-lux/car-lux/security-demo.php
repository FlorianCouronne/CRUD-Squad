<?php
/*
 * Security demo page - Member 6 (Security Specialist)
 * Shows the two protections working without needing any other member's code:
 *   1. CSRF: the form is only accepted if its hidden token matches the session.
 *   2. XSS:  whatever is typed is printed back with e(), so HTML/JavaScript is shown as text.
 */
require __DIR__ . '/includes/csrf.php';
require_once __DIR__ . '/includes/escape.php';

$submitted = null;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();                                   // 403 and stop if the token is missing or wrong
    $submitted = (string) ($_POST['message'] ?? ''); // only reached with a valid token
}

$pageTitle = 'Security Demo'; $active = '';
include 'includes/header.php';
?>
<main class="cl-section">
  <div class="container" style="max-width: 760px;">
    <span class="cl-tag">MEMBER 6 &middot; SECURITY</span>
    <h2>CSRF and XSS protection test</h2>
    <p class="cl-muted">Type anything below, including HTML or JavaScript such as
      <code>&lt;script&gt;alert('XSS')&lt;/script&gt;</code>, and submit.</p>

    <div class="cl-card">
      <form method="POST" action="security-demo.php">
        <?= csrf_field() ?>
        <label for="message" class="form-label">Message</label>
        <textarea id="message" name="message" class="form-control mb-3" rows="3" maxlength="500" required></textarea>
        <button type="submit" class="btn btn-cyan w-100">Submit</button>
      </form>
    </div>

    <?php if ($submitted !== null): ?>
      <div class="cl-card mt-4">
        <p class="mb-2"><strong>&#10003; CSRF check passed:</strong> the hidden token matched your session, so the request was accepted.</p>
        <p class="mb-2"><strong>Your input, displayed safely with <code>e()</code>:</strong></p>
        <div class="p-3 mb-3 border rounded"><?= e($submitted) ?></div>
        <p class="mb-2"><strong>What the server actually sent to the browser:</strong></p>
        <pre class="p-3 border rounded mb-0" style="white-space: pre-wrap;"><code><?= e(e($submitted)) ?></code></pre>
        <p class="cl-muted small mt-2 mb-0">The &lt; and &gt; characters were converted to &amp;lt; and &amp;gt;, so the browser shows them as text and never runs them.</p>
      </div>
    <?php endif; ?>
  </div>
</main>
<?php include 'includes/footer.php'; ?>
